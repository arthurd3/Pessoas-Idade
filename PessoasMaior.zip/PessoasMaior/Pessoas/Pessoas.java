

public class Pessoas
{
    private int idade;
    private String nome , email;
    private int  mes , dia , ano;
    
    public Pessoas(){
        
    }
    
    public Pessoas(int idade , String nome , String email , int mes , int dia , int ano){
        this.idade = idade;
        this.nome = nome;
        this.email = email;
        this.mes = mes;
        this.dia = dia;
        this.ano = ano;
    }

    
    public void setNome(String nome){
        this.nome=nome;
    }
    public String getNome(){
        return nome;
    }
    
    
    public void setIdade(int idade){
        this.idade=idade;
    }
    public int getIdade(){
        return idade;
    }
    
    
    public void setEmail(String email){
        this.email = email;
    }
    public String getEmail(){
        return email;
    }
    
    public void setDia(int dia){
        this.dia=dia;
    }
    public int getDia(){
        return dia;
    }
    
    
    public void setMes(int mes){
        this.mes=mes;
    }
    public int getMes(){
        return mes;
    }
    
    public void setAno(int ano){
        this.ano=ano;
    }
    public int getAno(){
        return ano;
    }
    public String getDataNascimento() {
        return String.format("%02d/%02d/%04d", dia, mes, ano);  // Formata como DD/MM/YYYY
    }
    
    public void informacoesPessoa(){
        System.out.println("Info : " + getNome());
        System.out.println("Nome : " + getNome());
        System.out.println("Idade : " + getIdade());
        System.out.println("Email : " + getEmail());
        System.out.println("Nascimento : " + getDataNascimento());
        if(idade > 17){
            System.out.println("Usuario : " + getNome() + " Com :"+ getIdade() +" Anos Esta Acima dos 17 anos");
        }else System.out.println("Usuario : " + getNome() + " Com :"+ getIdade() +" Anos Esta Abaixo dos 17 anos");
        System.out.println("\n \n");
    }
}
