
public class Main
{
    

    
    public static void main(String[] args)
    {
        Pessoas pessoa1 = new Pessoas();
        Pessoas pessoa2 = new Pessoas();
        
        pessoa1.setNome("Jose");
        pessoa1.setIdade(16);
        pessoa1.setEmail("josecouve@gmail.com");
        pessoa1.setDia(10);
        pessoa1.setMes(9);
        pessoa1.setAno(2045);
        
        pessoa1.informacoesPessoa();
        
        
        pessoa2.setNome("Arthur");
        pessoa2.setIdade(20);
        pessoa2.setEmail("arthurcampos@gmail.com");
        pessoa2.setDia(9);
        pessoa2.setMes(9);
        pessoa2.setAno(2005);
        
        pessoa2.informacoesPessoa();
    }

}
